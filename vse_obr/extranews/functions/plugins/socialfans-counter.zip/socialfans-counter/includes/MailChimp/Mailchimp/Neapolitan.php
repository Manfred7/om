<?php

if( !class_exists( 'Mailchimp_Neapolitan' ) ){


class Mailchimp_Neapolitan {
    public function __construct(Mailchimp $master) {
        $this->master = $master;
    }

}

}



