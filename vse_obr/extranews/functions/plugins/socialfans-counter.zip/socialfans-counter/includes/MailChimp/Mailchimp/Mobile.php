<?php

if( !class_exists( 'Mailchimp_Mobile' ) ){


class Mailchimp_Mobile {
    public function __construct(Mailchimp $master) {
        $this->master = $master;
    }

}

}



