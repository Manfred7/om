<?php $show_title = SFCounter_Widget_Options::show_title(); ?>
<?php $box_width = SFCounter_Widget_Options::box_width(); // widget columns count       ?>
<?php $lazy_load = SFCounter_Widget_Options::lazy_load(); ?>
<?php $animate_numbers = SFCounter_Widget_Options::animate_numbers(); ?>
<?php $max_duration = SFCounter_Widget_Options::animate_numbers(); ?>
<?php
$data = '';

if ( $animate_numbers ) {
  $data .= 'data-animate_numbers="1" ';
}

if ( $lazy_load ) {
  $data .= 'data-is_lazy="1" ';
}

if ( $max_duration ) {
  $data .= 'data-duration="' . $max_duration . '" ';
}
?>
<div class="sf-counter-container" style="<?php echo $box_width; ?>">
  <?php if ( $show_title ) { ?>
    <h3><?php echo $title; ?></h3>
  <?php } ?>
  <div class="sf-widget-holder" style="<?php echo $box_width; ?>" <?php echo $data; ?>>
    <?php include 'socialfans-counter-view-html.php'; ?>
  </div><!-- End Widget Holder -->

</div>