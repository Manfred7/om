<style type="text/css">
    #socialfans-accordion .form-field label,
    #stickyfans-accordion .form-field label {display: inline-block; width: 120px !important;}
    #socialfans-accordion .form-field input, #socialfans-accordion .form-field select,
    #stickyfans-accordion .form-field input, #stickyfans-accordion .form-field select{padding: 5px !important;vertical-align: middle; height: 26px;}
    #socialfans-accordion h3,
    #stickyfans-accordion h3{font-size: 12px !important; margin: 2px 0 0 0 !important; padding: .5em .5em .5em 2.2em !important; }
    #socialfans-accordion h3,
    #stickyfans-accordion h3,
    .form-field input, .form-field select{-webkit-border-radius: 0 !important; -khtml-border-radius: 0 !important; -moz-border-radius: 0 !important; border-radius: 0 !important; }
    #socialfans-accordion br.clear,
    #stickyfans-accordion br.clear{display: none !important;}
    .ui-state-hover, .ui-widget-content .ui-state-hover, .ui-widget-header .ui-state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus, .ui-widget-header .ui-state-focus{
        border: 1px solid #dfdfdf !important; background-image: none !important;cursor: move !important;
    }
    .ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default{
        border: 1px solid #dfdfdf !important; background-image: none !important;
    }
    .ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active{
        border: 1px solid #dfdfdf !important; background-image: none !important; background-color: #f1f1f1 !important;
    }
    .ui-widget-content{border: 1px solid #dfdfdf !important; border-top-width: 0 !important; background-color: rgb(252, 252, 252) !important; background-image: none !important;}
    .ui-corner-all, .ui-corner-bottom, .ui-corner-right, .ui-corner-br{
        -webkit-border-radius: 0 !important; -khtml-border-radius: 0 !important; -moz-border-radius: 0 !important; border-radius: 0 !important;
    }
    .ui-accordion .ui-accordion-content{padding: 5px 10px; font-size: 11px;}
    .hndle, .postbox{-webkit-border-radius: 0 !important; -khtml-border-radius: 0 !important; -moz-border-radius: 0 !important;}
    .hndle, .postbox{background-image: none !important;}
    #message{-webkit-border-radius: 0 !important; border-radius: 0 !important; background-color: rgb(241, 255, 240) !important; border-color: rgb(80, 128, 78) !important;}
    .sf_social_doc_row{float: right; position: relative; margin-top: -85px; width: 340px; height: 70px;}
    .sf_social_doc_row a{text-decoration: none;}
</style><!-- End Style -->