<p>
  <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo __( 'Title' , 'sfcounter' ); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name( 'title' ); ?>" id="<?php echo $this->get_field_id( 'title' ); ?>" class="widefat" value="<?php echo $instance['title']; ?>" />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'new_window' ); ?>"><?php echo __( 'New Window' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'new_window' ); ?>" id="<?php echo $this->get_field_id( 'new_window' ); ?>" value="1" <?php if ( 1 == $instance['new_window'] ) { echo ' checked="checked"'; } ?> />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'nofollow' ); ?>"><?php echo __( 'Nofollow Links' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'nofollow' ); ?>" id="<?php echo $this->get_field_id( 'nofollow' ); ?>" value="1" <?php if ( 1 == $instance['nofollow'] ) { echo ' checked="checked"'; } ?> />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'hide_title' ); ?>"><?php echo __( 'Hide Title' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'hide_title' ); ?>" id="<?php echo $this->get_field_id( 'hide_title' ); ?>" value="1" <?php if ( 1 == $instance['hide_title'] ) { echo ' checked="checked"'; } ?> />
  <span style="font-weight: 700; font-size: 0.9em"><em></em></span>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'hide_numbers' ); ?>"><?php echo __( 'Hide Numbers' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'hide_numbers' ); ?>" id="<?php echo $this->get_field_id( 'hide_numbers' ); ?>" value="1" <?php if ( 1 == $instance['hide_numbers'] ) { echo ' checked="checked"'; } ?> />
  <span style="font-weight: 700; font-size: 0.9em"><br /><em><?php echo __( 'show all enabled socials without numbers' , 'sfcounter' ); ?></em></span>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'show_total' ); ?>"><?php echo __( 'Show Total' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'show_total' ); ?>" id="<?php echo $this->get_field_id( 'show_total' ); ?>" value="1" <?php if ( 1 == $instance['show_total'] ) { echo ' checked="checked"'; } ?> />
  <span style="font-weight: 700; font-size: 0.9em"><br /><em><?php echo __( 'Show sum social accounts fans' , 'sfcounter' ); ?></em></span>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'box_width' ); ?>"><?php echo __( 'Box Width' , 'sfcounter' ); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name( 'box_width' ); ?>" id="<?php echo $this->get_field_id( 'box_width' ); ?>" value="<?php echo $instance['box_width'];?>" size="5" /> px
  <span style="font-weight: 700; font-size: 0.9em"><br /><em><?php echo __( 'force box with custom width' , 'sfcounter' ); ?></em></span>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'is_lazy' ); ?>"><?php echo __( 'Lazy Load' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'is_lazy' ); ?>" id="<?php echo $this->get_field_id( 'is_lazy' ); ?>" value="1" <?php if ( 1 == $instance['is_lazy'] ) { echo ' checked="checked"'; } ?> />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'animate_numbers' ); ?>"><?php echo __( 'Animate Numbers' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'animate_numbers' ); ?>" id="<?php echo $this->get_field_id( 'animate_numbers' ); ?>" value="1" <?php if ( 1 == $instance['animate_numbers'] ) { echo ' checked="checked"'; } ?> />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'max_duration' ); ?>"><?php echo __( 'Max Duration' , 'sfcounter' ); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name( 'max_duration' ); ?>" id="<?php echo $this->get_field_id( 'max_duration' ); ?>" value="<?php echo $instance['max_duration'];?>" />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'columns' ); ?>"><?php echo __( 'Columns' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'columns' ); ?>" id="<?php echo $this->get_field_id( 'columns' ); ?>" class="widefat">
    <option value="1" <?php if ( $instance['columns'] == 1 ) { echo 'selected="selected"'; } ?>>1 <?php echo __( 'Column' , 'sfcounter' ); ?></option>
    <option value="2" <?php if ( $instance['columns'] == 2 ) { echo 'selected="selected"'; } ?>>2 <?php echo __( 'Columns' , 'sfcounter' ); ?></option>
    <option value="3" <?php if ( $instance['columns'] == 3 ) { echo 'selected="selected"'; } ?>>3 <?php echo __( 'Columns' , 'sfcounter' ); ?></option>
    <option value="4" <?php if ( $instance['columns'] == 4 ) { echo 'selected="selected"'; } ?>>4 <?php echo __( 'Columns' , 'sfcounter' ); ?></option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'effects' ); ?>"><?php echo __( 'Effects' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'effects' ); ?>" id="<?php echo $this->get_field_id( 'effects' ); ?>" class="widefat">
    <option value="sf-no-effect" <?php if ( $instance['effects'] == 'sf-no-effect' ) { echo 'selected="selected"'; } ?>><?php echo __( 'No Effect (No Hover Text)' , 'sfcounter' ); ?></option>
    <option value="sf-view-first" <?php if ( $instance['effects'] == 'sf-view-first' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Effect' , 'sfcounter' ); ?> 1</option>
    <option value="sf-view-two" <?php if ( $instance['effects'] == 'sf-view-two' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Effect' , 'sfcounter' ); ?> 2</option>
    <option value="sf-view-three" <?php if ( $instance['effects'] == 'sf-view-three' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Effect' , 'sfcounter' ); ?> 3</option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'shake' ); ?>"><?php echo __( 'Shake' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'shake' ); ?>" id="<?php echo $this->get_field_id( 'shake' ); ?>" class="widefat">
    <option value="" <?php if ( $instance['shake'] == '' ) { echo 'selected="selected"'; } ?>><?php echo __( 'None' , 'sfcounter' ); ?></option>
    <option value="sf-shake" <?php if ( $instance['shake'] == 'sf-shake' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Normal' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-slow" <?php if ( $instance['shake'] == 'sf-shake sf-shake-slow' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Slow' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-hard" <?php if ( $instance['shake'] == 'sf-shake sf-shake-hard' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Hard' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-little" <?php if ( $instance['shake'] == 'sf-shake sf-shake-little' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Little' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-horizontal" <?php if ( $instance['shake'] == 'sf-shake sf-shake-horizontal' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Horizontal' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-vertical" <?php if ( $instance['shake'] == 'sf-shake sf-shake-vertical' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Vertical' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-rotate" <?php if ( $instance['shake'] == 'sf-shake sf-shake-rotate' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Rotate' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-opacity" <?php if ( $instance['shake'] == 'sf-shake sf-shake-opacity' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Opacity' , 'sfcounter' ); ?></option>
    <option value="sf-shake sf-shake-crazy" <?php if ( $instance['shake'] == 'sf-shake sf-shake-crazy' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Crazy' , 'sfcounter' ); ?></option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'icon_color' ); ?>"><?php echo __( 'Icon / Text Color' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'icon_color' ); ?>" id="<?php echo $this->get_field_id( 'icon_color' ); ?>" class="widefat">
    <option value="light" <?php if ( $instance['icon_color'] == 'light' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Light' , 'sfcounter' ); ?></option>
    <option value="dark" <?php if ( $instance['icon_color'] == 'dark' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Dark' , 'sfcounter' ); ?></option>
    <option value="colord" <?php if ( $instance['icon_color'] == 'colord' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Colord' , 'sfcounter' ); ?></option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'bg_color' ); ?>"><?php echo __( 'Background Color' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'bg_color' ); ?>" id="<?php echo $this->get_field_id( 'bg_color' ); ?>" class="widefat">
    <option value="light" <?php if ( $instance['bg_color'] == 'light' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Light' , 'sfcounter' ); ?></option>
    <option value="dark" <?php if ( $instance['bg_color'] == 'dark' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Dark' , 'sfcounter' ); ?></option>
    <option value="colord" <?php if ( $instance['bg_color'] == 'colord' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Colord' , 'sfcounter' ); ?></option>
    <option value="transparent" <?php if ( $instance['bg_color'] == 'transparent' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Transparent' , 'sfcounter' ); ?></option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'hover_text_color' ); ?>"><?php echo __( 'Hover Text Color' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'hover_text_color' ); ?>" id="<?php echo $this->get_field_id( 'hover_text_color' ); ?>" class="widefat">
    <option value="light" <?php if ( $instance['hover_text_color'] == 'light' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Light' , 'sfcounter' ); ?></option>
    <option value="dark" <?php if ( $instance['hover_text_color'] == 'dark' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Dark' , 'sfcounter' ); ?></option>
    <option value="colord" <?php if ( $instance['hover_text_color'] == 'colord' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Colord' , 'sfcounter' ); ?></option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'hover_text_bg_color' ); ?>"><?php echo __( 'Hover Text Background Color' , 'sfcounter' ); ?>:</label>
  <select name="<?php echo $this->get_field_name( 'hover_text_bg_color' ); ?>" id="<?php echo $this->get_field_id( 'hover_text_bg_color' ); ?>" class="widefat">
    <option value="light" <?php if ( $instance['hover_text_bg_color'] == 'light' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Light' , 'sfcounter' ); ?></option>
    <option value="dark" <?php if ( $instance['hover_text_bg_color'] == 'dark' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Dark' , 'sfcounter' ); ?></option>
    <option value="colord" <?php if ( $instance['hover_text_bg_color'] == 'colord' ) { echo 'selected="selected"'; } ?>><?php echo __( 'Colord' , 'sfcounter' ); ?></option>
  </select>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'show_diff' ); ?>"><?php echo __( 'Lastweek diffrence' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'show_diff' ); ?>" id="<?php echo $this->get_field_id( 'show_diff' ); ?>" value="1" <?php if ( 1 == $instance['show_diff'] ) { echo ' checked="checked"'; } ?> />
  <span style="font-weight: 700; font-size: 0.9em"><br /><em><?php echo __( 'show last week diffrence count' , 'sfcounter' ); ?></em></span>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'show_diff_lt_zero' ); ?>"><?php echo __( 'Show diffrence less than zero' , 'sfcounter' ); ?>:</label>
  <input type="checkbox" name="<?php echo $this->get_field_name( 'show_diff_lt_zero' ); ?>" id="<?php echo $this->get_field_id( 'show_diff_lt_zero' ); ?>" value="1" <?php if ( 1 == $instance['show_diff_lt_zero'] ) { echo ' checked="checked"'; } ?> />
  <span style="font-weight: 700; font-size: 0.9em"><br /><em><?php echo __( 'show last week diffrence count if less than zero' , 'sfcounter' ); ?></em></span>
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'diff_count_text_color' ); ?>"><?php echo __( 'Diff text color' , 'sfcounter' ); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name( 'diff_count_text_color' ); ?>" id="<?php echo $this->get_field_id( 'diff_count_text_color' ); ?>" class="widefat sf-color-picker" value="<?php echo $instance['diff_count_text_color']; ?>" />
</p>

<p>
  <label for="<?php echo $this->get_field_id( 'diff_count_bg_color' ); ?>"><?php echo __( 'Diff Background color' , 'sfcounter' ); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name( 'diff_count_bg_color' ); ?>" id="<?php echo $this->get_field_id( 'diff_count_bg_color' ); ?>" class="widefat sf-color-picker" value="<?php echo $instance['diff_count_bg_color']; ?>" />
</p>
